---
layout: post
title: "西江月·夜行九龙湖校区"
description: ""
category: "随笔"
tags: [科研,生活]
summary: ""
---

路灯倏亮惊喵，台风浅夜鸣蛙。计院楼前思科研，忽见车倒一片。

七八个星天外，两三点雨山前。今日兰楼风雨边，路转南门再见。

